package com.redmagic.gamespace.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.redmagic.gamespace.model.PerformanceMode
import com.redmagic.gamespace.model.TelemetryData
import com.redmagic.gamespace.ui.theme.*

/**
 * Sci-Fi Circular Arc HUD Gauge displaying telemetry metric.
 */
@Composable
fun HudArcGauge(
    title: String,
    valueText: String,
    unit: String,
    progress: Float, // 0.0 to 1.0
    accentColor: Color,
    modifier: Modifier = Modifier,
    subText: String? = null
) {
    val animatedProgress by animateFloatAsState(
        targetValue = progress.coerceIn(0f, 1f),
        animationSpec = tween(600),
        label = "gauge_progress"
    )

    Box(
        modifier = modifier
            .size(105.dp)
            .background(CarbonCardBackground, CyberCardShape)
            .border(1.dp, CarbonBorder, CyberCardShape)
            .padding(8.dp),
        contentAlignment = Alignment.Center
    ) {
        // High-tech Arc rendering
        Canvas(modifier = Modifier.fillMaxSize().padding(4.dp)) {
            val strokeWidth = 5.dp.toPx()
            val startAngle = 135f
            val sweepAngle = 270f

            // Background track
            drawArc(
                color = CarbonSurface,
                startAngle = startAngle,
                sweepAngle = sweepAngle,
                useCenter = false,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round),
                size = Size(size.width, size.height)
            )

            // Active neon gauge arc
            drawArc(
                brush = Brush.sweepGradient(
                    listOf(accentColor.copy(alpha = 0.4f), accentColor)
                ),
                startAngle = startAngle,
                sweepAngle = sweepAngle * animatedProgress,
                useCenter = false,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round),
                size = Size(size.width, size.height)
            )

            // Sci-fi tick mark at start
            val center = Offset(size.width / 2f, size.height / 2f)
            drawCircle(
                color = accentColor,
                radius = 2.dp.toPx(),
                center = Offset(center.x, center.y + size.height / 2f - 4.dp.toPx())
            )
        }

        // Inner Text Content
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = title,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                color = TextSecondary,
                letterSpacing = 1.sp
            )
            Row(
                verticalAlignment = Alignment.Bottom
            ) {
                Text(
                    text = valueText,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = TextPrimary,
                    fontFamily = FontFamily.Monospace
                )
                if (unit.isNotEmpty()) {
                    Text(
                        text = unit,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = accentColor,
                        modifier = Modifier.padding(start = 2.dp, bottom = 2.dp)
                    )
                }
            }
            if (subText != null) {
                Text(
                    text = subText,
                    fontSize = 8.sp,
                    color = TextMuted,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

/**
 * Combined HUD Telemetry Strip for FPS, CPU, RAM, and Battery Temp.
 */
@Composable
fun TelemetryHudDashboard(
    telemetry: TelemetryData,
    modifier: Modifier = Modifier
) {
    // Determine thermal warning color
    val thermalColor by animateColorAsState(
        targetValue = when {
            telemetry.batteryTempCelsius >= 43.0f -> NeonRed
            telemetry.batteryTempCelsius >= 39.0f -> CyberYellow
            else -> NeonCyan
        },
        label = "temp_color"
    )

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // 1. FPS Monitor
        HudArcGauge(
            title = "FPS",
            valueText = "${telemetry.fps}",
            unit = "",
            progress = telemetry.fps / 90.0f,
            accentColor = NeonCyan,
            subText = "TARGET: 90"
        )

        // 2. CPU Usage & Helio G80 Clock
        HudArcGauge(
            title = "CPU",
            valueText = "${telemetry.cpuUsagePercent}",
            unit = "%",
            progress = telemetry.cpuUsagePercent / 100f,
            accentColor = NeonRed,
            subText = "${telemetry.cpuFreqGhz} GHz"
        )

        // 3. RAM Availability
        HudArcGauge(
            title = "RAM",
            valueText = "${telemetry.ramAvailableMb}",
            unit = "MB",
            progress = telemetry.ramUsagePercent / 100f,
            accentColor = MatrixGreen,
            subText = "${telemetry.ramUsagePercent}% USED"
        )

        // 4. Battery Thermal
        HudArcGauge(
            title = "TEMP",
            valueText = String.format("%.1f", telemetry.batteryTempCelsius),
            unit = "°C",
            progress = (telemetry.batteryTempCelsius - 25f) / 30f,
            accentColor = thermalColor,
            subText = if (telemetry.batteryTempCelsius > 42f) "THROTTLING" else "OPTIMAL"
        )
    }
}

/**
 * Performance Mode Selector mimicking RedMagic Game Space:
 * ECO | BALANCE | RISE / DIABLO
 */
@Composable
fun PerformanceModeSelector(
    selectedMode: PerformanceMode,
    onModeSelected: (PerformanceMode) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .background(CarbonCardBackground, CyberCardShape)
            .border(1.dp, CarbonBorder, CyberCardShape)
            .padding(4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        PerformanceMode.entries.forEach { mode ->
            val isSelected = mode == selectedMode
            val targetColor = when (mode) {
                PerformanceMode.ECO -> MatrixGreen
                PerformanceMode.BALANCE -> NeonCyan
                PerformanceMode.RISE_DIABLO -> NeonRed
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 4.dp)
                    .background(
                        if (isSelected) targetColor.copy(alpha = 0.2f) else Color.Transparent,
                        CyberButtonShape
                    )
                    .border(
                        width = if (isSelected) 1.5.dp else 0.dp,
                        color = if (isSelected) targetColor else Color.Transparent,
                        shape = CyberButtonShape
                    )
                    .clickable { onModeSelected(mode) }
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = mode.title.uppercase(),
                        fontWeight = if (isSelected) FontWeight.Black else FontWeight.Bold,
                        fontSize = 11.sp,
                        color = if (isSelected) targetColor else TextSecondary,
                        letterSpacing = 0.8.sp
                    )
                    Text(
                        text = "${mode.targetHz.toInt()}Hz",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (isSelected) TextPrimary else TextMuted
                    )
                }
            }
        }
    }
}
