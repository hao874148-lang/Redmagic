package com.redmagic.gamespace.ui

import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.redmagic.gamespace.model.GameItem
import com.redmagic.gamespace.model.PerformanceMode
import com.redmagic.gamespace.service.GameOverlayService
import com.redmagic.gamespace.shizuku.ShizukuManager
import com.redmagic.gamespace.shizuku.ShizukuStatus
import com.redmagic.gamespace.ui.components.Game3DCarousel
import com.redmagic.gamespace.ui.components.PerformanceModeSelector
import com.redmagic.gamespace.ui.components.TelemetryHudDashboard
import com.redmagic.gamespace.ui.theme.*
import com.redmagic.gamespace.util.HardwareMonitor
import com.redmagic.gamespace.util.PerformanceController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class GameLauncherActivity : ComponentActivity() {

    private lateinit var hardwareMonitor: HardwareMonitor

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        hideSystemBars()
        hardwareMonitor = HardwareMonitor(this)
        hardwareMonitor.start()

        // Cache baseline system settings
        kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
            PerformanceController.saveDefaultSettings()
        }

        setContent {
            RedMagicTheme {
                GameSpaceScreen(
                    onLaunchGame = { game, mode -> launchGameWithBoost(game, mode) },
                    onRequestShizuku = { ShizukuManager.requestPermission() },
                    onRequestOverlayPermission = { requestOverlayPermission() }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        hideSystemBars()
        ShizukuManager.refreshStatus()
    }

    override fun onDestroy() {
        super.onDestroy()
        hardwareMonitor.stop()
    }

    private fun hideSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    private fun requestOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        }
    }

    private fun launchGameWithBoost(game: GameItem, mode: PerformanceMode) {
        val scope = kotlinx.coroutines.CoroutineScope(Dispatchers.Main)
        scope.launch {
            Toast.makeText(this@GameLauncherActivity, "Đang kích hoạt ${mode.title} cho Helio G80...", Toast.LENGTH_SHORT).show()

            // 1. Apply system tweaks via ADB (Shizuku)
            PerformanceController.applyMode(mode)

            // 2. Launch In-Game Sidebar Service if permitted
            if (Settings.canDrawOverlays(this@GameLauncherActivity)) {
                GameOverlayService.start(this@GameLauncherActivity)
            } else {
                Toast.makeText(this@GameLauncherActivity, "Cấp quyền Cửa sổ nổi để dùng Sidebar!", Toast.LENGTH_LONG).show()
                requestOverlayPermission()
            }

            // 3. Launch target game application
            val launchIntent = packageManager.getLaunchIntentForPackage(game.packageName)
            if (launchIntent != null) {
                startActivity(launchIntent)
            } else {
                Toast.makeText(this@GameLauncherActivity, "Không thể mở ứng dụng: ${game.packageName}", Toast.LENGTH_SHORT).show()
            }
        }
    }
}

@Composable
fun GameSpaceScreen(
    onLaunchGame: (GameItem, PerformanceMode) -> Unit,
    onRequestShizuku: () -> Unit,
    onRequestOverlayPermission: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    val shizukuStatus by ShizukuManager.status.collectAsState()
    val currentMode by PerformanceController.currentMode.collectAsState()

    val hardwareMonitor = remember { HardwareMonitor(context).apply { start() } }
    val telemetry by hardwareMonitor.telemetry.collectAsState()

    DisposableEffect(Unit) {
        onDispose { hardwareMonitor.stop() }
    }

    // List of games
    var installedGames by remember { mutableStateOf<List<GameItem>>(emptyList()) }

    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            installedGames = loadInstalledGames(context.packageManager)
        }
    }

    val pagerState = rememberPagerState(
        initialPage = (installedGames.size / 2).coerceAtLeast(0),
        pageCount = { installedGames.size }
    )

    var showShizukuDialog by remember { mutableStateOf(false) }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = CarbonDarkBackground
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 10.dp, bottom = 10.dp, start = 14.dp, end = 14.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // 1. Top Cyber Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Left Brand Logo
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(NeonRed, CircleShape)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "REDMAGIC",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        color = TextPrimary,
                        letterSpacing = 2.sp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "SPACE // A32 G80",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = NeonCyan,
                        fontFamily = FontFamily.Monospace
                    )
                }

                // Shizuku Status Pill
                ShizukuStatusBadge(
                    status = shizukuStatus,
                    onClick = {
                        when (shizukuStatus) {
                            ShizukuStatus.READY -> {
                                Toast.makeText(context, "Shizuku ADB Elevated Active!", Toast.LENGTH_SHORT).show()
                            }
                            ShizukuStatus.PERMISSION_REQUIRED -> {
                                onRequestShizuku()
                            }
                            ShizukuStatus.NOT_RUNNING -> {
                                showShizukuDialog = true
                            }
                        }
                    }
                )
            }

            // 2. HUD Telemetry Strip
            TelemetryHudDashboard(
                telemetry = telemetry,
                modifier = Modifier.fillMaxWidth()
            )

            // 3. 3D Game Carousel
            Game3DCarousel(
                games = installedGames,
                pagerState = pagerState,
                onLaunchGame = { game ->
                    onLaunchGame(game, currentMode)
                },
                modifier = Modifier.weight(1f)
            )

            // 4. Performance Mode Profile Selector
            PerformanceModeSelector(
                selectedMode = currentMode,
                onModeSelected = { mode ->
                    coroutineScope.launch {
                        PerformanceController.applyMode(mode)
                    }
                }
            )
        }

        // Shizuku Guide Dialog if not running
        if (showShizukuDialog) {
            AlertDialog(
                onDismissRequest = { showShizukuDialog = false },
                title = {
                    Text(
                        text = "KÍCH HOẠT SHIZUKU (ADB)",
                        fontWeight = FontWeight.Black,
                        color = NeonRedBright
                    )
                },
                text = {
                    Text(
                        text = "Để can thiệp ép 90Hz, diệt ngầm và tối ưu sâu CPU Helio G80 không cần Root:\n\n" +
                                "1. Khởi động ứng dụng Shizuku qua 'Wireless Debugging' (Android 11+) hoặc qua PC.\n" +
                                "2. Nếu bạn đang chạy Termux, bạn có thể gõ lệnh 'rish' để kích hoạt.\n" +
                                "3. Mở lại Game Space và nhấn 'Cấp Quyền'.",
                        fontSize = 13.sp,
                        color = TextPrimary
                    )
                },
                confirmButton = {
                    TextButton(onClick = { showShizukuDialog = false }) {
                        Text("ĐÃ HIỂU", color = NeonCyan, fontWeight = FontWeight.Bold)
                    }
                },
                containerColor = CarbonCardBackground,
                shape = CyberCardShape
            )
        }
    }
}

@Composable
fun ShizukuStatusBadge(
    status: ShizukuStatus,
    onClick: () -> Unit
) {
    val (statusText, badgeColor) = when (status) {
        ShizukuStatus.READY -> "ADB ELEVATED" to MatrixGreen
        ShizukuStatus.PERMISSION_REQUIRED -> "GRANT PERMISSION" to CyberYellow
        ShizukuStatus.NOT_RUNNING -> "SHIZUKU OFF" to NeonRed
    }

    Row(
        modifier = Modifier
            .background(CarbonCardBackground, CyberButtonShape)
            .border(1.dp, badgeColor, CyberButtonShape)
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(6.dp)
                .background(badgeColor, CircleShape)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = statusText,
            fontSize = 9.sp,
            fontWeight = FontWeight.Black,
            color = badgeColor,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 1.sp
        )
    }
}

/**
 * Discovers installed games and high-profile competitive titles.
 */
private fun loadInstalledGames(pm: PackageManager): List<GameItem> {
    val gamingKeywords = listOf(
        "game", "pubg", "freefire", "genshin", "arena", "roblox",
        "mobilelegends", "wildrift", "speed", "codm", "honkai", "garena"
    )

    val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
        addCategory(Intent.CATEGORY_LAUNCHER)
    }

    val resolveInfos = pm.queryIntentActivities(mainIntent, 0)
    val games = mutableListOf<GameItem>()

    for (info in resolveInfos) {
        val appInfo = info.activityInfo.applicationInfo
        val pkg = appInfo.packageName

        val isDeclaredGame = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            appInfo.category == ApplicationInfo.CATEGORY_GAME
        } else {
            @Suppress("DEPRECATION")
            (appInfo.flags and ApplicationInfo.FLAG_IS_GAME) != 0
        }

        val matchesKeyword = gamingKeywords.any { pkg.lowercase().contains(it) }

        if (isDeclaredGame || matchesKeyword) {
            games.add(
                GameItem(
                    packageName = pkg,
                    title = info.loadLabel(pm).toString(),
                    icon = info.loadIcon(pm),
                    isGameCategory = true
                )
            )
        }
    }

    // Fallback demo games if testing on empty development device
    if (games.isEmpty()) {
        games.add(
            GameItem(
                packageName = "com.garena.game.kgvn",
                title = "Liên Quân Mobile",
                icon = null
            )
        )
        games.add(
            GameItem(
                packageName = "com.dts.freefireth",
                title = "Free Fire MAX",
                icon = null
            )
        )
        games.add(
            GameItem(
                packageName = "com.vng.pubgmobile",
                title = "PUBG Mobile VN",
                icon = null
            )
        )
        games.add(
            GameItem(
                packageName = "com.miHoYo.GenshinImpact",
                title = "Genshin Impact",
                icon = null
            )
        )
    }

    return games
}
