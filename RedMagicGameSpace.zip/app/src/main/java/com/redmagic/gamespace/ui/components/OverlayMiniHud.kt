package com.redmagic.gamespace.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.redmagic.gamespace.model.TelemetryData
import com.redmagic.gamespace.ui.theme.*

/**
 * RedMagic In-Game Overlay Content:
 * Toggles between a subtle edge pull-tab and the full Mini-HUD console.
 */
@Composable
fun OverlayMiniHud(
    telemetry: TelemetryData,
    isExpanded: Boolean,
    isDndBlocked: Boolean,
    isBrightnessLocked: Boolean,
    is90Hz: Boolean,
    onToggleExpand: () -> Unit,
    onInstantBoost: () -> Unit,
    onToggleDnd: () -> Unit,
    onToggleBrightnessLock: () -> Unit,
    onToggleRefreshRate: () -> Unit,
    onCloseService: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier) {
        if (!isExpanded) {
            // Collapsed Edge Tab
            Box(
                modifier = Modifier
                    .width(32.dp)
                    .height(90.dp)
                    .background(CarbonCardBackground.copy(alpha = 0.88f), CyberButtonShape)
                    .border(1.5.dp, NeonRed, CyberButtonShape)
                    .clickable { onToggleExpand() },
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.ChevronLeft,
                        contentDescription = "Expand HUD",
                        tint = NeonRedBright,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "${telemetry.fps}",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Black,
                        color = NeonCyan,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        } else {
            // Expanded Mini-HUD Panel
            Box(
                modifier = Modifier
                    .width(330.dp)
                    .background(CarbonDarkBackground.copy(alpha = 0.94f), CyberCardShape)
                    .border(1.5.dp, NeonRed, CyberCardShape)
                    .padding(14.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Header Bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .background(NeonRed, CyberSmallShape)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "REDMAGIC HUD",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black,
                                color = TextPrimary,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "G80 BOOST",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = NeonCyan
                            )
                        }

                        Row {
                            IconButton(
                                onClick = onToggleExpand,
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ChevronRight,
                                    contentDescription = "Minimize",
                                    tint = TextSecondary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            IconButton(
                                onClick = onCloseService,
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Close HUD",
                                    tint = NeonRedBright,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }

                    // Telemetry Matrix
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(CarbonSurface, CyberSmallShape)
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        MiniTelemetryStat(title = "FPS", value = "${telemetry.fps}", color = NeonCyan)
                        MiniTelemetryStat(title = "CPU", value = "${telemetry.cpuUsagePercent}%", color = NeonRed)
                        MiniTelemetryStat(title = "RAM FREE", value = "${telemetry.ramAvailableMb}M", color = MatrixGreen)
                        MiniTelemetryStat(
                            title = "TEMP",
                            value = "${telemetry.batteryTempCelsius.toInt()}°C",
                            color = if (telemetry.batteryTempCelsius > 42f) NeonRed else CyberYellow
                        )
                    }

                    // Primary Boost Action
                    Button(
                        onClick = onInstantBoost,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = NeonRed,
                            contentColor = Color.White
                        ),
                        shape = CyberButtonShape,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(40.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Bolt,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "BOOST RAM & FLUSH CACHE",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.sp
                            )
                        }
                    }

                    // Quick Toggle Grid
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OverlayToggleButton(
                            title = if (isDndBlocked) "DND ON" else "DND OFF",
                            icon = if (isDndBlocked) Icons.Default.NotificationsOff else Icons.Default.Notifications,
                            isActive = isDndBlocked,
                            onClick = onToggleDnd,
                            modifier = Modifier.weight(1f)
                        )

                        OverlayToggleButton(
                            title = if (isBrightnessLocked) "BRIGHT LOCK" else "AUTO BRIGHT",
                            icon = Icons.Default.BrightnessMedium,
                            isActive = isBrightnessLocked,
                            onClick = onToggleBrightnessLock,
                            modifier = Modifier.weight(1f)
                        )

                        OverlayToggleButton(
                            title = if (is90Hz) "FORCE 90Hz" else "60Hz ECO",
                            icon = Icons.Default.Speed,
                            isActive = is90Hz,
                            onClick = onToggleRefreshRate,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MiniTelemetryStat(
    title: String,
    value: String,
    color: Color
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = title, fontSize = 8.sp, fontWeight = FontWeight.Bold, color = TextSecondary)
        Text(
            text = value,
            fontSize = 13.sp,
            fontWeight = FontWeight.Black,
            fontFamily = FontFamily.Monospace,
            color = color
        )
    }
}

@Composable
private fun OverlayToggleButton(
    title: String,
    icon: ImageVector,
    isActive: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val activeColor = if (isActive) NeonCyan else TextSecondary
    val bgColor = if (isActive) CarbonSurface else CarbonCardBackground

    Box(
        modifier = modifier
            .background(bgColor, CyberSmallShape)
            .border(1.dp, if (isActive) NeonCyan else CarbonBorder, CyberSmallShape)
            .clickable { onClick() }
            .padding(vertical = 8.dp, horizontal = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = activeColor,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = title,
                fontSize = 8.sp,
                fontWeight = FontWeight.Bold,
                color = activeColor,
                maxLines = 1
            )
        }
    }
}
