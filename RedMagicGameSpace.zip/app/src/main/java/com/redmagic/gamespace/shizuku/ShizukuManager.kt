package com.redmagic.gamespace.shizuku

import android.content.pm.PackageManager
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.TimeUnit

enum class ShizukuStatus {
    NOT_RUNNING,
    PERMISSION_REQUIRED,
    READY
}

data class ShellResult(
    val exitCode: Int,
    val stdout: String,
    val stderr: String,
    val isSuccess: Boolean = exitCode == 0
)

/**
 * Singleton ShizukuManager to manage ADB elevated access, permission checks,
 * and high-performance rootless shell execution for Galaxy A32.
 */
object ShizukuManager {
    private const val TAG = "ShizukuManager"
    const val SHIZUKU_REQUEST_CODE = 8001

    private val _status = MutableStateFlow(ShizukuStatus.NOT_RUNNING)
    val status: StateFlow<ShizukuStatus> = _status.asStateFlow()

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        Log.i(TAG, "Shizuku Binder Received")
        refreshStatus()
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        Log.w(TAG, "Shizuku Binder Dead")
        _status.value = ShizukuStatus.NOT_RUNNING
    }

    private val permissionResultListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == SHIZUKU_REQUEST_CODE) {
            if (grantResult == PackageManager.PERMISSION_GRANTED) {
                Log.i(TAG, "Shizuku permission granted by user")
                _status.value = ShizukuStatus.READY
            } else {
                Log.w(TAG, "Shizuku permission denied by user")
                _status.value = ShizukuStatus.PERMISSION_REQUIRED
            }
        }
    }

    fun init() {
        try {
            Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
            Shizuku.addBinderDeadListener(binderDeadListener)
            Shizuku.addRequestPermissionResultListener(permissionResultListener)
            refreshStatus()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize Shizuku listeners: ${e.message}")
            _status.value = ShizukuStatus.NOT_RUNNING
        }
    }

    fun cleanup() {
        try {
            Shizuku.removeBinderReceivedListener(binderReceivedListener)
            Shizuku.removeBinderDeadListener(binderDeadListener)
            Shizuku.removeRequestPermissionResultListener(permissionResultListener)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to cleanup Shizuku listeners: ${e.message}")
        }
    }

    fun refreshStatus() {
        if (!isShizukuAvailable()) {
            _status.value = ShizukuStatus.NOT_RUNNING
            return
        }

        if (hasPermission()) {
            _status.value = ShizukuStatus.READY
        } else {
            _status.value = ShizukuStatus.PERMISSION_REQUIRED
        }
    }

    fun isShizukuAvailable(): Boolean {
        return try {
            Shizuku.pingBinder()
        } catch (e: Throwable) {
            false
        }
    }

    fun hasPermission(): Boolean {
        return try {
            if (!isShizukuAvailable()) return false
            if (Shizuku.isPre_V11()) {
                false
            } else {
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
            }
        } catch (e: Throwable) {
            false
        }
    }

    fun requestPermission() {
        try {
            if (isShizukuAvailable() && !hasPermission()) {
                Shizuku.requestPermission(SHIZUKU_REQUEST_CODE)
            }
        } catch (e: Throwable) {
            Log.e(TAG, "Failed to request Shizuku permission: ${e.message}")
        }
    }

    /**
     * Executes an ADB shell command with elevated privileges using Shizuku.newProcess()
     */
    suspend fun execute(command: String, timeoutMs: Long = 5000): ShellResult = withContext(Dispatchers.IO) {
        if (!hasPermission()) {
            Log.w(TAG, "Attempted execute without Shizuku permission: $command")
            return@withContext ShellResult(-1, "", "Shizuku permission not granted")
        }

        var process: java.lang.Process? = null
        try {
            // Shizuku.newProcess executes a command inside adb shell context
            process = Shizuku.newProcess(arrayOf("sh", "-c", command), null, null)

            val stdoutBuilder = StringBuilder()
            val stderrBuilder = StringBuilder()

            val stdoutJob = kotlinx.coroutines.async {
                BufferedReader(InputStreamReader(process.inputStream)).use { reader ->
                    var line: String?
                    while (reader.readLine().also { line = it } != null) {
                        stdoutBuilder.append(line).append("\n")
                    }
                }
            }

            val stderrJob = kotlinx.coroutines.async {
                BufferedReader(InputStreamReader(process.errorStream)).use { reader ->
                    var line: String?
                    while (reader.readLine().also { line = it } != null) {
                        stderrBuilder.append(line).append("\n")
                    }
                }
            }

            // Await streams and wait for process completion with timeout
            val exited = process.waitFor(timeoutMs, TimeUnit.MILLISECONDS)
            stdoutJob.await()
            stderrJob.await()

            if (!exited) {
                process.destroyForcibly()
                return@withContext ShellResult(-2, stdoutBuilder.toString().trim(), "Command timed out after ${timeoutMs}ms")
            }

            val exitCode = process.exitValue()
            ShellResult(
                exitCode = exitCode,
                stdout = stdoutBuilder.toString().trim(),
                stderr = stderrBuilder.toString().trim()
            )
        } catch (e: Throwable) {
            Log.e(TAG, "Error executing Shizuku command: $command", e)
            ShellResult(-1, "", e.message ?: "Unknown error")
        } finally {
            process?.destroy()
        }
    }

    /**
     * Executes multiple shell commands sequentially.
     */
    suspend fun executeBatch(commands: List<String>): List<ShellResult> = withContext(Dispatchers.IO) {
        val results = mutableListOf<ShellResult>()
        for (cmd in commands) {
            results.add(execute(cmd))
        }
        results
    }
}
