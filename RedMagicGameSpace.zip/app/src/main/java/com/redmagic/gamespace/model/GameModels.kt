package com.redmagic.gamespace.model

import android.graphics.drawable.Drawable

/**
 * Representation of an installed game on the device.
 */
data class GameItem(
    val packageName: String,
    val title: String,
    val icon: Drawable?,
    val isGameCategory: Boolean = true,
    val customPerformanceMode: PerformanceMode = PerformanceMode.RISE_DIABLO
)

/**
 * RedMagic inspired Performance Profiles.
 */
enum class PerformanceMode(
    val title: String,
    val codename: String,
    val description: String,
    val targetHz: Float,
    val animScale: Float,
    val killBackground: Boolean,
    val dndEnabled: Boolean
) {
    ECO(
        title = "Eco Mode",
        codename = "ENERGY_SAVER",
        description = "Tiết kiệm pin, giới hạn 60Hz, giữ nguyên đa nhiệm thông thường.",
        targetHz = 60.0f,
        animScale = 1.0f,
        killBackground = false,
        dndEnabled = false
    ),
    BALANCE(
        title = "Balance Mode",
        codename = "SMART_ADAPTIVE",
        description = "Cân bằng Helio G80: Mượt mà 90Hz, tối ưu animation 0.5x.",
        targetHz = 90.0f,
        animScale = 0.5f,
        killBackground = false,
        dndEnabled = false
    ),
    RISE_DIABLO(
        title = "Rise / Diablo",
        codename = "EXTREME_PERF",
        description = "Ép xung tối đa Helio G80: Khóa cứng 90Hz, diệt ngầm cực đoan, chặn DND.",
        targetHz = 90.0f,
        animScale = 0.0f,
        killBackground = true,
        dndEnabled = true
    )
}

/**
 * Real-time hardware telemetry data for HUD.
 */
data class TelemetryData(
    val fps: Int = 60,
    val cpuUsagePercent: Int = 0,
    val cpuFreqGhz: Float = 2.0f,
    val ramAvailableMb: Long = 0,
    val ramTotalMb: Long = 0,
    val ramUsagePercent: Int = 0,
    val batteryTempCelsius: Float = 32.0f
)
