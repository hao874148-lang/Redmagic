package com.redmagic.gamespace.ui.components

import android.graphics.drawable.BitmapDrawable
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import com.redmagic.gamespace.model.GameItem
import com.redmagic.gamespace.ui.theme.*
import kotlin.math.absoluteValue

/**
 * 3D Carousel Pager displaying games with realistic perspective rotation and scale effects.
 */
@Composable
fun Game3DCarousel(
    games: List<GameItem>,
    pagerState: PagerState,
    onLaunchGame: (GameItem) -> Unit,
    modifier: Modifier = Modifier
) {
    if (games.isEmpty()) {
        Box(
            modifier = modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Default.SportsEsports,
                    contentDescription = null,
                    tint = TextSecondary,
                    modifier = Modifier.size(64.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "NO GAMES DETECTED IN STORAGE",
                    color = TextSecondary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }
        }
        return
    }

    HorizontalPager(
        state = pagerState,
        contentPadding = PaddingValues(horizontal = 140.dp),
        pageSpacing = 16.dp,
        modifier = modifier.fillMaxWidth()
    ) { page ->
        val game = games[page]
        val pageOffset = ((pagerState.currentPage - page) + pagerState.currentPageOffsetFraction)
        val absOffset = pageOffset.absoluteValue

        // 3D Perspective Transformation
        val scale = 1f - (absOffset * 0.18f).coerceIn(0f, 0.4f)
        val rotationY = (pageOffset * -28f).coerceIn(-45f, 45f)
        val alpha = 1f - (absOffset * 0.45f).coerceIn(0f, 0.8f)

        Game3DCard(
            game = game,
            isSelected = page == pagerState.currentPage,
            onLaunch = { onLaunchGame(game) },
            modifier = Modifier
                .graphicsLayer {
                    this.scaleX = scale
                    this.scaleY = scale
                    this.rotationY = rotationY
                    this.alpha = alpha
                    this.cameraDistance = 18 * density
                }
        )
    }
}

/**
 * Individual RedMagic cyber game card.
 */
@Composable
fun Game3DCard(
    game: GameItem,
    isSelected: Boolean,
    onLaunch: () -> Unit,
    modifier: Modifier = Modifier
) {
    val borderColor = if (isSelected) NeonRed else CarbonBorder
    val glowBrush = Brush.verticalGradient(
        listOf(
            if (isSelected) NeonRed.copy(alpha = 0.25f) else Color.Transparent,
            CarbonCardBackground
        )
    )

    Box(
        modifier = modifier
            .width(260.dp)
            .height(210.dp)
            .background(CarbonCardBackground, CyberCardShape)
            .background(glowBrush, CyberCardShape)
            .border(width = if (isSelected) 2.dp else 1.dp, color = borderColor, shape = CyberCardShape)
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "GALAXY OPTIMIZED",
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Black,
                    color = if (isSelected) NeonCyan else TextMuted,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "HELIO G80",
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold,
                    color = NeonRedBright
                )
            }

            // Game Icon
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .background(CarbonSurface, CyberCardShape)
                    .border(1.dp, if (isSelected) NeonCyan else CarbonBorder, CyberCardShape)
                    .padding(4.dp),
                contentAlignment = Alignment.Center
            ) {
                if (game.icon != null) {
                    val bitmap = if (game.icon is BitmapDrawable) {
                        (game.icon as BitmapDrawable).bitmap
                    } else {
                        game.icon.toBitmap(128, 128)
                    }
                    Image(
                        bitmap = bitmap.asImageBitmap(),
                        contentDescription = game.title,
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(CyberCardShape)
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.SportsEsports,
                        contentDescription = null,
                        tint = NeonCyan,
                        modifier = Modifier.size(48.dp)
                    )
                }
            }

            // Game Name
            Text(
                text = game.title,
                fontSize = 15.sp,
                fontWeight = FontWeight.Black,
                color = TextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center
            )

            // Neon Launch Button
            Button(
                onClick = onLaunch,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isSelected) NeonRed else CarbonSurface,
                    contentColor = Color.White
                ),
                shape = CyberButtonShape,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(36.dp)
                    .border(
                        width = 1.dp,
                        color = if (isSelected) NeonRedBright else CarbonBorder,
                        shape = CyberButtonShape
                    )
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "LAUNCH GAME",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp
                    )
                }
            }
        }
    }
}
