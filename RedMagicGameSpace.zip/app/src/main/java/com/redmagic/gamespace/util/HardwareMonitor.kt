package com.redmagic.gamespace.util

import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.view.Choreographer
import com.redmagic.gamespace.model.TelemetryData
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.RandomAccessFile

/**
 * Real-time Hardware Telemetry Engine tailored for Samsung Galaxy A32 (Helio G80).
 * Queries Battery Thermals, RAM allocation, CPU load, and Display FPS.
 */
class HardwareMonitor(private val context: Context) {

    private val _telemetry = MutableStateFlow(TelemetryData())
    val telemetry: StateFlow<TelemetryData> = _telemetry.asStateFlow()

    private val monitorScope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var isMonitoring = false

    private var lastTotalCpuTime: Long = 0
    private var lastIdleCpuTime: Long = 0

    // FPS estimation vars
    private var frameCount = 0
    private var lastFpsTimestamp = System.currentTimeMillis()
    private var currentFps = 60
    private var frameCallback: Choreographer.FrameCallback? = null

    private var batteryReceiver: BroadcastReceiver? = null
    private var currentBatteryTemp = 32.0f

    fun start() {
        if (isMonitoring) return
        isMonitoring = true

        registerBatteryReceiver()
        startFpsCounter()

        monitorScope.launch {
            while (isActive && isMonitoring) {
                updateMetrics()
                delay(1000) // Telemetry sample interval: 1Hz
            }
        }
    }

    fun stop() {
        isMonitoring = false
        monitorScope.cancel()
        batteryReceiver?.let {
            try {
                context.unregisterReceiver(it)
            } catch (_: Exception) {}
        }
        batteryReceiver = null

        frameCallback?.let {
            Choreographer.getInstance().removeFrameCallback(it)
        }
    }

    private fun registerBatteryReceiver() {
        val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        batteryReceiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, intent: Intent?) {
                intent?.let {
                    val rawTemp = it.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 320)
                    currentBatteryTemp = rawTemp / 10.0f
                }
            }
        }
        context.registerReceiver(batteryReceiver, filter)
    }

    private fun startFpsCounter() {
        frameCallback = object : Choreographer.FrameCallback {
            override fun doFrame(frameTimeNanos: Long) {
                frameCount++
                val now = System.currentTimeMillis()
                val delta = now - lastFpsTimestamp
                if (delta >= 1000) {
                    currentFps = (frameCount * 1000L / delta).toInt().coerceIn(1, 90)
                    frameCount = 0
                    lastFpsTimestamp = now
                }
                if (isMonitoring) {
                    Choreographer.getInstance().postFrameCallback(this)
                }
            }
        }
        Choreographer.getInstance().postFrameCallback(frameCallback!!)
    }

    private fun updateMetrics() {
        // 1. RAM Information
        val actManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        actManager.getMemoryInfo(memInfo)

        val totalRamMb = memInfo.totalMem / (1024 * 1024)
        val freeRamMb = memInfo.availMem / (1024 * 1024)
        val usedRamMb = totalRamMb - freeRamMb
        val ramUsagePercent = ((usedRamMb.toDouble() / totalRamMb.toDouble()) * 100).toInt()

        // 2. CPU Usage & Clock Frequency (Helio G80 Cortex-A75 @ 2.0GHz max)
        val cpuUsage = readCpuUsagePercent()
        val cpuFreqGhz = readHelioG80Frequency()

        _telemetry.value = TelemetryData(
            fps = currentFps,
            cpuUsagePercent = cpuUsage,
            cpuFreqGhz = cpuFreqGhz,
            ramAvailableMb = freeRamMb,
            ramTotalMb = totalRamMb,
            ramUsagePercent = ramUsagePercent,
            batteryTempCelsius = currentBatteryTemp
        )
    }

    /**
     * Reads /proc/stat to compute instantaneous CPU load across all 8 cores
     */
    private fun readCpuUsagePercent(): Int {
        return try {
            val reader = RandomAccessFile("/proc/stat", "r")
            val load = reader.readLine()
            reader.close()

            val tokens = load.split("\\s+".toRegex())
            if (tokens.size >= 5) {
                val user = tokens[1].toLong()
                val nice = tokens[2].toLong()
                val system = tokens[3].toLong()
                val idle = tokens[4].toLong()
                val iowait = if (tokens.size > 5) tokens[5].toLong() else 0L
                val irq = if (tokens.size > 6) tokens[6].toLong() else 0L
                val softirq = if (tokens.size > 7) tokens[7].toLong() else 0L

                val total = user + nice + system + idle + iowait + irq + softirq

                if (lastTotalCpuTime == 0L) {
                    lastTotalCpuTime = total
                    lastIdleCpuTime = idle
                    return 25 // Default initial estimation
                }

                val totalDiff = total - lastTotalCpuTime
                val idleDiff = idle - lastIdleCpuTime

                lastTotalCpuTime = total
                lastIdleCpuTime = idle

                if (totalDiff > 0) {
                    val usage = (((totalDiff - idleDiff).toDouble() / totalDiff.toDouble()) * 100).toInt()
                    return usage.coerceIn(0, 100)
                }
            }
            30
        } catch (e: Exception) {
            25 // Fallback
        }
    }

    /**
     * Reads Helio G80 Big Cluster (Cortex-A75 cores 6 & 7) clock speed
     */
    private fun readHelioG80Frequency(): Float {
        val paths = listOf(
            "/sys/devices/system/cpu/cpu6/cpufreq/scaling_cur_freq",
            "/sys/devices/system/cpu/cpu7/cpufreq/scaling_cur_freq",
            "/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq"
        )

        for (path in paths) {
            try {
                val reader = RandomAccessFile(path, "r")
                val line = reader.readLine()
                reader.close()
                if (line != null) {
                    val khz = line.trim().toLong()
                    val ghz = khz / 1_000_000.0f
                    if (ghz in 0.5f..2.5f) {
                        return (Math.round(ghz * 10.0f) / 10.0f)
                    }
                }
            } catch (_: Exception) {}
        }
        return 2.0f // Helio G80 base peak
    }
}
