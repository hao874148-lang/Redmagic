package com.redmagic.gamespace.util

import android.content.Context
import android.util.Log
import com.redmagic.gamespace.model.PerformanceMode
import com.redmagic.gamespace.shizuku.ShizukuManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext

/**
 * Performance Controller specifically engineered for Samsung Galaxy A32 4G (Helio G80).
 * Dispatches elevated ADB commands via Shizuku to toggle 90Hz, clear RAM,
 * suppress notifications, and remove rendering bottlenecks.
 */
object PerformanceController {
    private const val TAG = "PerformanceController"

    private val _currentMode = MutableStateFlow(PerformanceMode.BALANCE)
    val currentMode: StateFlow<PerformanceMode> = _currentMode.asStateFlow()

    private val _isBoosting = MutableStateFlow(false)
    val isBoosting: StateFlow<Boolean> = _isBoosting.asStateFlow()

    // Cache original settings to restore after game exit
    private var originalPeakRefreshRate: String = "90.0"
    private var originalMinRefreshRate: String = "60.0"
    private var originalWindowAnimScale: String = "1.0"
    private var originalTransitionAnimScale: String = "1.0"
    private var originalAnimatorDurationScale: String = "1.0"
    private var originalZenMode: String = "0"
    private var originalHeadsUp: String = "1"

    suspend fun saveDefaultSettings() = withContext(Dispatchers.IO) {
        if (!ShizukuManager.hasPermission()) return@withContext
        try {
            originalPeakRefreshRate = ShizukuManager.execute("settings get system peak_refresh_rate").stdout.ifEmpty { "90.0" }
            originalMinRefreshRate = ShizukuManager.execute("settings get system min_refresh_rate").stdout.ifEmpty { "60.0" }
            originalWindowAnimScale = ShizukuManager.execute("settings get global window_animation_scale").stdout.ifEmpty { "1.0" }
            originalTransitionAnimScale = ShizukuManager.execute("settings get global transition_animation_scale").stdout.ifEmpty { "1.0" }
            originalAnimatorDurationScale = ShizukuManager.execute("settings get global animator_duration_scale").stdout.ifEmpty { "1.0" }
            originalZenMode = ShizukuManager.execute("settings get global zen_mode").stdout.ifEmpty { "0" }
            originalHeadsUp = ShizukuManager.execute("settings get global heads_up_notifications_enabled").stdout.ifEmpty { "1" }
            Log.d(TAG, "Saved system default parameters successfully.")
        } catch (e: Exception) {
            Log.e(TAG, "Error saving default settings: ${e.message}")
        }
    }

    /**
     * Applies the selected RedMagic performance profile to the Samsung A32.
     */
    suspend fun applyMode(mode: PerformanceMode) = withContext(Dispatchers.IO) {
        _currentMode.value = mode
        Log.i(TAG, "Applying profile: ${mode.title} (Target: ${mode.targetHz}Hz, Anim: ${mode.animScale}x)")

        if (!ShizukuManager.hasPermission()) {
            Log.w(TAG, "Shizuku not ready. Skipping ADB system commands.")
            return@withContext
        }

        val commands = mutableListOf<String>()

        // 1. Galaxy A32 90Hz Display Refresh Rate Switch
        // Samsung One UI supports 90Hz and 60Hz modes
        commands.add("settings put system peak_refresh_rate ${mode.targetHz}")
        commands.add("settings put system min_refresh_rate ${mode.targetHz}")
        // Samsung specific refresh rate flag (0 = 60Hz, 1/2 = 90Hz)
        val samsungRefreshMode = if (mode.targetHz >= 90.0f) "1" else "0"
        commands.add("settings put system refresh_rate_mode $samsungRefreshMode")

        // 2. System Animation Scales for instant frame-drop-free responsiveness
        commands.add("settings put global window_animation_scale ${mode.animScale}")
        commands.add("settings put global transition_animation_scale ${mode.animScale}")
        commands.add("settings put global animator_duration_scale ${mode.animScale}")

        // 3. Do Not Disturb & Heads-Up Notifications
        if (mode.dndEnabled) {
            // Block floating popups and silence notifications
            commands.add("settings put global zen_mode 1")
            commands.add("settings put global heads_up_notifications_enabled 0")
        } else {
            commands.add("settings put global zen_mode 0")
            commands.add("settings put global heads_up_notifications_enabled 1")
        }

        // 4. Mode-specific Helio G80 Optimizations
        when (mode) {
            PerformanceMode.ECO -> {
                // Return to normal power mode
                commands.add("cmd power set-fixed-performance-mode-enabled false")
            }
            PerformanceMode.BALANCE -> {
                commands.add("cmd power set-fixed-performance-mode-enabled false")
            }
            PerformanceMode.RISE_DIABLO -> {
                // Aggressive RAM purification and performance lock
                commands.add("am kill-all")
                commands.add("cmd package trim-caches 4096M")
                commands.add("cmd power set-fixed-performance-mode-enabled true")
                // Android Game Driver hint
                commands.add("settings put global game_driver_all_apps 1")
            }
        }

        // Dispatch commands
        val results = ShizukuManager.executeBatch(commands)
        results.forEach { res ->
            if (!res.isSuccess && res.stderr.isNotEmpty()) {
                Log.w(TAG, "ADB command output error: ${res.stderr}")
            }
        }
    }

    /**
     * Instant Boost: Purges background memory and trims caches immediately.
     */
    suspend fun instantBoost(context: Context? = null): Boolean = withContext(Dispatchers.IO) {
        _isBoosting.value = true
        var success = false
        try {
            Log.i(TAG, "Executing Instant Boost for Helio G80...")
            if (ShizukuManager.hasPermission()) {
                val boostCommands = listOf(
                    "am kill-all",
                    "cmd package trim-caches 4096M",
                    "sync",
                    "echo 3 > /proc/sys/vm/drop_caches"
                )
                ShizukuManager.executeBatch(boostCommands)
                success = true
            }
            // Standard Android API cleanup fallback
            context?.let { ctx ->
                val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as? android.app.ActivityManager
                am?.runningAppProcesses?.forEach { process ->
                    if (process.pkgList != null && process.pkgList.isNotEmpty()) {
                        process.pkgList.forEach { pkg ->
                            if (pkg != ctx.packageName) {
                                am.killBackgroundProcesses(pkg)
                            }
                        }
                    }
                }
            }
            kotlinx.coroutines.delay(600) // Brief delay for telemetry sensor refresh
        } catch (e: Exception) {
            Log.e(TAG, "Failed to instant boost: ${e.message}")
        } finally {
            _isBoosting.value = false
        }
        success
    }

    /**
     * Restores device parameters back to standard values when exiting game.
     */
    suspend fun restoreDefaultSettings() = withContext(Dispatchers.IO) {
        if (!ShizukuManager.hasPermission()) return@withContext
        Log.i(TAG, "Restoring original system settings...")
        val restoreCmds = listOf(
            "settings put system peak_refresh_rate $originalPeakRefreshRate",
            "settings put system min_refresh_rate $originalMinRefreshRate",
            "settings put global window_animation_scale $originalWindowAnimScale",
            "settings put global transition_animation_scale $originalTransitionAnimScale",
            "settings put global animator_duration_scale $originalAnimatorDurationScale",
            "settings put global zen_mode $originalZenMode",
            "settings put global heads_up_notifications_enabled $originalHeadsUp",
            "cmd power set-fixed-performance-mode-enabled false"
        )
        ShizukuManager.executeBatch(restoreCmds)
        _currentMode.value = PerformanceMode.BALANCE
    }

    /**
     * Set display refresh rate directly (60Hz or 90Hz)
     */
    suspend fun setRefreshRate(hz: Float) = withContext(Dispatchers.IO) {
        if (!ShizukuManager.hasPermission()) return@withContext
        val mode = if (hz >= 90f) "1" else "0"
        val cmds = listOf(
            "settings put system peak_refresh_rate $hz",
            "settings put system min_refresh_rate $hz",
            "settings put system refresh_rate_mode $mode"
        )
        ShizukuManager.executeBatch(cmds)
    }

    /**
     * Toggle Heads-up notifications / DND
     */
    suspend fun toggleNotificationBlock(block: Boolean) = withContext(Dispatchers.IO) {
        if (!ShizukuManager.hasPermission()) return@withContext
        val zen = if (block) "1" else "0"
        val headsUp = if (block) "0" else "1"
        ShizukuManager.executeBatch(
            listOf(
                "settings put global zen_mode $zen",
                "settings put global heads_up_notifications_enabled $headsUp"
            )
        )
    }
}
