package com.redmagic.gamespace.service

import android.app.Notification
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.compose.runtime.*
import androidx.compose.ui.platform.ComposeView
import androidx.core.app.NotificationCompat
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.redmagic.gamespace.GameSpaceApp
import com.redmagic.gamespace.model.TelemetryData
import com.redmagic.gamespace.ui.components.OverlayMiniHud
import com.redmagic.gamespace.ui.theme.RedMagicTheme
import com.redmagic.gamespace.util.HardwareMonitor
import com.redmagic.gamespace.util.PerformanceController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Foreground In-Game Overlay Service providing floating HUD sidebar.
 */
class GameOverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private var overlayView: ComposeView? = null
    private val lifecycleOwner = OverlayLifecycleOwner()
    private val serviceScope = CoroutineScope(Dispatchers.Main)
    private lateinit var hardwareMonitor: HardwareMonitor

    private lateinit var layoutParams: WindowManager.LayoutParams
    private var isExpandedState by mutableStateOf(false)
    private var isDndState by mutableStateOf(true)
    private var isBrightnessLockedState by mutableStateOf(false)
    private var is90HzState by mutableStateOf(true)

    override fun onCreate() {
        super.onCreate()
        lifecycleOwner.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        hardwareMonitor = HardwareMonitor(this)
        hardwareMonitor.start()

        startForegroundNotification()
        setupOverlayWindow()
    }

    private fun startForegroundNotification() {
        val notification: Notification = NotificationCompat.Builder(this, GameSpaceApp.OVERLAY_CHANNEL_ID)
            .setContentTitle("RedMagic Game Space Active")
            .setContentText("Helio G80 In-Game telemetry & ADB Booster running")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .build()

        startForeground(1001, notification)
    }

    private fun setupOverlayWindow() {
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 0
            y = 300 // Initial vertical position along the right edge
        }

        overlayView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(lifecycleOwner)
            setViewTreeViewModelStoreOwner(lifecycleOwner)
            setViewTreeSavedStateRegistryOwner(lifecycleOwner)

            setContent {
                val telemetry by hardwareMonitor.telemetry.collectAsState()

                RedMagicTheme {
                    OverlayMiniHud(
                        telemetry = telemetry,
                        isExpanded = isExpandedState,
                        isDndBlocked = isDndState,
                        isBrightnessLocked = isBrightnessLockedState,
                        is90Hz = is90HzState,
                        onToggleExpand = {
                            isExpandedState = !isExpandedState
                            updateWindowDimensions()
                        },
                        onInstantBoost = {
                            serviceScope.launch {
                                PerformanceController.instantBoost(this@GameOverlayService)
                            }
                        },
                        onToggleDnd = {
                            isDndState = !isDndState
                            serviceScope.launch {
                                PerformanceController.toggleNotificationBlock(isDndState)
                            }
                        },
                        onToggleBrightnessLock = {
                            isBrightnessLockedState = !isBrightnessLockedState
                        },
                        onToggleRefreshRate = {
                            is90HzState = !is90HzState
                            serviceScope.launch {
                                val hz = if (is90HzState) 90.0f else 60.0f
                                PerformanceController.setRefreshRate(hz)
                            }
                        },
                        onCloseService = {
                            stopSelf()
                        }
                    )
                }
            }
        }

        // Add touch drag handling for floating pill
        enableDragging(overlayView!!)

        try {
            windowManager.addView(overlayView, layoutParams)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun updateWindowDimensions() {
        // Refresh layout when expanding / collapsing to avoid dead touch zones
        try {
            windowManager.updateViewLayout(overlayView, layoutParams)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun enableDragging(view: View) {
        var initialY = 0
        var initialTouchY = 0f

        view.setOnTouchListener { _, event ->
            // Only allow vertical dragging when collapsed
            if (isExpandedState) return@setOnTouchListener false

            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialY = layoutParams.y
                    initialTouchY = event.rawY
                    false
                }
                MotionEvent.ACTION_MOVE -> {
                    layoutParams.y = initialY + (event.rawY - initialTouchY).toInt()
                    windowManager.updateViewLayout(view, layoutParams)
                    true
                }
                else -> false
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        lifecycleOwner.onDestroy()
        serviceScope.cancel()
        hardwareMonitor.stop()

        overlayView?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {}
        }

        // Restore system settings safely
        CoroutineScope(Dispatchers.IO).launch {
            PerformanceController.restoreDefaultSettings()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        fun start(context: Context) {
            val intent = Intent(context, GameOverlayService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, GameOverlayService::class.java)
            context.stopService(intent)
        }
    }
}
