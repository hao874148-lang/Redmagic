package com.redmagic.gamespace.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

// RedMagic Cyberpunk Color Palette
val CarbonDarkBackground = Color(0xFF07080B)
val CarbonCardBackground = Color(0xFF101218)
val CarbonSurface = Color(0xFF191C24)
val CarbonBorder = Color(0xFF282C3A)

val NeonRed = Color(0xFFFF1E27)
val NeonRedBright = Color(0xFFFF3B43)
val NeonRedDim = Color(0xFF6B0E12)

val NeonCyan = Color(0xFF00F0FF)
val NeonCyanBright = Color(0xFF5CF6FF)
val NeonCyanDim = Color(0xFF006B73)

val CyberYellow = Color(0xFFFFD000)
val MatrixGreen = Color(0xFF00FF66)

val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFF8E95A5)
val TextMuted = Color(0xFF555B6E)

// Cyberpunk Chamfered Shapes
val CyberCardShape = CutCornerShape(topStart = 12.dp, bottomEnd = 12.dp)
val CyberButtonShape = CutCornerShape(topStart = 8.dp, bottomEnd = 8.dp)
val CyberSmallShape = CutCornerShape(topStart = 4.dp, bottomEnd = 4.dp)

private val RedMagicColorScheme = darkColorScheme(
    primary = NeonRed,
    onPrimary = Color.White,
    primaryContainer = NeonRedDim,
    onPrimaryContainer = NeonRedBright,
    secondary = NeonCyan,
    onSecondary = Color.Black,
    secondaryContainer = NeonCyanDim,
    onSecondaryContainer = NeonCyanBright,
    tertiary = CyberYellow,
    background = CarbonDarkBackground,
    onBackground = TextPrimary,
    surface = CarbonCardBackground,
    onSurface = TextPrimary,
    surfaceVariant = CarbonSurface,
    onSurfaceVariant = TextSecondary,
    outline = CarbonBorder
)

@Composable
fun RedMagicTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = RedMagicColorScheme,
        shapes = Shapes(
            small = CyberSmallShape,
            medium = CyberButtonShape,
            large = CyberCardShape
        ),
        content = content
    )
}
