package com.redmagic.gamespace

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.redmagic.gamespace.shizuku.ShizukuManager

class GameSpaceApp : Application() {

    companion object {
        const val OVERLAY_CHANNEL_ID = "game_space_overlay_channel"
        lateinit var instance: GameSpaceApp
            private set
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        createNotificationChannel()
        ShizukuManager.init()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                OVERLAY_CHANNEL_ID,
                "Game Space HUD Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Running in-game floating sidebar and telemetry monitor"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }
}
